function Menu() {
    return(
    <>
        <a href="/">Home</a>&nbsp;&nbsp;&nbsp;
        <a href="/contato">Contato</a> &nbsp;&nbsp;&nbsp;
        <a href="/sobre">Sobre</a> 

    </>
    )

}

export default Menu 